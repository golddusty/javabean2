package com.titan.test;

import java.rmi.RemoteException;

public interface Test72Remote extends javax.ejb.EJBObject 
{
   public String test72a() throws RemoteException;
   public String test72b() throws RemoteException;
   public String test72c() throws RemoteException;
   public String test72d() throws RemoteException;
   public String test72e() throws RemoteException;
   public String test72f() throws RemoteException;
}
