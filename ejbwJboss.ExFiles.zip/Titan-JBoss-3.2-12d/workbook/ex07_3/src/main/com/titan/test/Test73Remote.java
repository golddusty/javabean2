package com.titan.test;

import java.rmi.RemoteException;

public interface Test73Remote extends javax.ejb.EJBObject 
{
   public String test73() throws RemoteException;
}
