package com.titan.test;

import java.rmi.RemoteException;

public interface Test82Remote extends javax.ejb.EJBObject 
{
   public String initialize() throws RemoteException;
   public String test82a() throws RemoteException;
   public String test82b() throws RemoteException;
   public String test82c() throws RemoteException;
   public String test82d() throws RemoteException;
   public String test82e() throws RemoteException;
   public String test82f() throws RemoteException;
   public String test82g() throws RemoteException;
   public String test82h() throws RemoteException;
   public String test82i() throws RemoteException;
   public String test82j() throws RemoteException;
   public String test82k() throws RemoteException;
   public String test82Dynamic() throws RemoteException;
}
