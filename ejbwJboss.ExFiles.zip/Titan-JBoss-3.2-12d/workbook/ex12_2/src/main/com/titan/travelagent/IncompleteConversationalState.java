package com.titan.travelagent;

public class IncompleteConversationalState extends java.lang.Exception
{
   public IncompleteConversationalState ()
   {
      super ();
   }
   
   public IncompleteConversationalState (String msg)
   {
      super (msg);
   }  
}
