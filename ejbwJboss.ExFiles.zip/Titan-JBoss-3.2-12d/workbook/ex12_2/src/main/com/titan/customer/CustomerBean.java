package com.titan.customer;

import com.titan.address.AddressHomeLocal;
import com.titan.address.AddressLocal;
import com.titan.phone.PhoneHomeLocal;
import com.titan.phone.PhoneLocal;

import javax.naming.InitialContext;
import javax.ejb.CreateException;
import javax.naming.NamingException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

public abstract class CustomerBean implements javax.ejb.EntityBean
{   
   public Integer ejbCreate (Integer id) throws CreateException
   {
      this.setId (id);
      return null;
   }
   
   public void ejbPostCreate (Integer id) { }
   
   // business methods
   //
   public Name getName ()
   {
      Name name = new Name (getLastName (),getFirstName ());
      return name;
   }
   
   public void setName (Name name)
   {
      setLastName (name.getLastName ());
      setFirstName (name.getFirstName ());
   }
   
   
   public void addPhoneNumber (String number, byte type)
   throws NamingException, CreateException
   {      
      InitialContext jndiEnc = new InitialContext ( );
      PhoneHomeLocal phoneHome = (PhoneHomeLocal)(jndiEnc.lookup ("PhoneHomeLocal"));
      
      PhoneLocal phone = phoneHome.create (number,type);
      
      Collection phoneNumbers = this.getPhoneNumbers ( );
      phoneNumbers.add (phone);      
   }
   
   public void removePhoneNumber (byte typeToRemove)
   {      
      Collection phoneNumbers = this.getPhoneNumbers ( );
      Iterator iterator = phoneNumbers.iterator ();
      
      while(iterator.hasNext ())
      {
         PhoneLocal phone = (PhoneLocal)iterator.next ();
         if (phone.getType () == typeToRemove)
         {
            phoneNumbers.remove (phone);
            break;
         }         
      }
   }
   
   public void updatePhoneNumber (String number, byte typeToUpdate)
   {      
      Collection phoneNumbers = this.getPhoneNumbers ( );
      Iterator iterator = phoneNumbers.iterator ();
      
      while(iterator.hasNext ())
      {
         PhoneLocal phone = (PhoneLocal)iterator.next ();
         if (phone.getType () == typeToUpdate)
         {
            phone.setNumber (number);
            break;
         }
      }
   }
   
   public Vector getPhoneList ()
   {      
      Vector vv = new Vector ();
      Collection phoneNumbers = this.getPhoneNumbers ();
      Iterator iterator = phoneNumbers.iterator ();
      
      while(iterator.hasNext ())
      {
         PhoneLocal phone = (PhoneLocal)iterator.next ();
         String ss = "Type="+phone.getType ()+"  Number="+phone.getNumber ();
         vv.add (ss);
      }
      return vv;
   }
   
   public void setAddress (String street, String city, String state, String zip)
   throws NamingException, CreateException
   {      
      AddressLocal addr = this.getHomeAddress ( );
      
      if (addr == null)
      {
         // Customer doesn't have an address yet. Create a new one.
         //
         InitialContext cntx = new InitialContext ( );
         AddressHomeLocal addrHome =
         (AddressHomeLocal)cntx.lookup ("AddressHomeLocal");
         addr = addrHome.createAddress (street, city, state, zip);
         this.setHomeAddress (addr);
      } 
      else
      {
         // Customer already has an address. Change its fields
         //
         addr.setStreet (street);
         addr.setCity (city);
         addr.setState (state);
         addr.setZip (zip);
      }
   }
   
   public AddressDO getAddress ()
   {      
      AddressLocal addrLocal = this.getHomeAddress ();
      
      String street = addrLocal.getStreet ();
      String city = addrLocal.getCity ();
      String state = addrLocal.getState ();
      String zip = addrLocal.getZip ();
      AddressDO addrValue = new AddressDO (street,city,state,zip);
      
      return addrValue;
   }
   
   public void setAddress (AddressDO addrValue)
   throws CreateException, NamingException
   {      
      String street = addrValue.getStreet ();
      String city = addrValue.getCity ();
      String state = addrValue.getState ();
      String zip = addrValue.getZip ();
      
      setAddress (street,city,state,zip);
   }
   
   // persistent relationships
   //
   public abstract AddressLocal getHomeAddress ();
   public abstract void setHomeAddress (AddressLocal address);
   
   public abstract CreditCardLocal getCreditCard ();
   public abstract void setCreditCard (CreditCardLocal card);
   
   public abstract Collection getPhoneNumbers ( );
   public abstract void setPhoneNumbers (Collection phones);
   
   public abstract Collection getReservations ();
   public abstract void setReservations (Collection reservations);
   
   // abstract accessor methods
   //
   public abstract Integer getId ();
   public abstract void setId (Integer id);
   
   public abstract String getLastName ();
   public abstract void setLastName (String lname);
   
   public abstract String getFirstName ();
   public abstract void setFirstName (String fname);
   
   public abstract boolean getHasGoodCredit ();
   public abstract void setHasGoodCredit (boolean flag);
   
   // EntityBean (empty) implementation
   //
   public void setEntityContext (javax.ejb.EntityContext ec) {}
   public void unsetEntityContext () {}
   public void ejbLoad () {}
   public void ejbStore () {}
   public void ejbActivate () {}
   public void ejbPassivate () {}
   public void ejbRemove () {}   
}
