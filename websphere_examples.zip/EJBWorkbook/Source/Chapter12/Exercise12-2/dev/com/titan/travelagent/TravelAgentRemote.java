package com.titan.travelagent;

import java.rmi.RemoteException;
import javax.ejb.FinderException;
import com.titan.processpayment.CreditCardDO;

public interface TravelAgentRemote extends javax.ejb.EJBObject {

    public void setCruiseID(Integer cruise) 
        throws RemoteException, FinderException;

    public void setCabinID(Integer cabin) 
        throws RemoteException, FinderException;

    public TicketDO bookPassage(CreditCardDO card, double price)
        throws RemoteException,IncompleteConversationalState;   
               
    public String [] listAvailableCabins(int bedCount)
        throws RemoteException, IncompleteConversationalState;
}
