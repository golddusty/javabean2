package com.titan.travelagent;

import java.sql.*;
import javax.sql.DataSource;
import java.util.Vector;
import java.rmi.RemoteException;
import javax.naming.NamingException;
import javax.ejb.EJBException;
import com.titan.processpayment.*;
import com.titan.cruise.*;
import com.titan.customer.*;
import com.titan.cabin.*;
import com.titan.reservation.*;

public class TravelAgentBean implements javax.ejb.SessionBean {

    public CustomerRemote customer;
    public CruiseRemote cruise;
    public CabinRemote cabin;

    public javax.ejb.SessionContext ejbContext;

    public javax.naming.Context jndiContext;

    public void ejbCreate(CustomerRemote cust) {
        customer = cust;
    }
    public void setCabinID(Integer cabinID)
        throws javax.ejb.FinderException { 
        try { 
            CabinHomeRemote home = (CabinHomeRemote)
            getHome("CabinHomeRemote",CabinHomeRemote.class);
            cabin = home.findByPrimaryKey(cabinID);
        } catch(Exception re) {
		System.out.println("Exception caught " + re);
		re.printStackTrace();
            throw new EJBException(re);
        }
    }
    public void setCruiseID(Integer cruiseID)
        throws javax.ejb.FinderException { 
        try { 
            CruiseHomeRemote home = (CruiseHomeRemote)
            getHome("CruiseHomeRemote", CruiseHomeRemote.class);
            cruise = home.findByPrimaryKey(cruiseID);
        } catch(Exception re) {
		System.out.println("Exception caught " + re);
		re.printStackTrace();
            throw new EJBException(re);
        }
        
    }
    public TicketDO bookPassage(CreditCardDO card, double price)
        throws IncompleteConversationalState {
                   
        if (customer == null || cruise == null || cabin == null){
            throw new IncompleteConversationalState();
        }
        try {
            ReservationHomeRemote resHome =  
            (ReservationHomeRemote)getHome("ReservationHomeRemote",
                                   ReservationHomeRemote.class);
            ReservationRemote reservation =
                resHome.create(customer, cruise, cabin, price, new Date(System.currentTimeMillis()));
            ProcessPaymentHomeRemote ppHome =  
            (ProcessPaymentHomeRemote)           
                getHome("ProcessPaymentHomeRemote",
                ProcessPaymentHomeRemote.class);
            ProcessPaymentRemote process = ppHome.create();
            process.byCredit(customer, card, price);

            TicketDO ticket = 
                new TicketDO(customer,cruise,cabin,price);
            return ticket;
        } catch(Exception e) {
		System.out.println("Exception caught " + e);
            throw new EJBException(e);
        }
    }
    public void ejbRemove() {}
    public void ejbActivate() {}
    public void ejbPassivate() {}
    
    public void setSessionContext(javax.ejb.SessionContext cntx) 
    {

        ejbContext = cntx;
        try {
            jndiContext = new javax.naming.InitialContext();
        } catch(NamingException ne) {

            throw new EJBException(ne);
        }
    }
    protected Object getHome(String name,Class type) {
        try {
            Object ref =  
                jndiContext.lookup("java:comp/env/ejb/"+name);
            return javax.rmi.PortableRemoteObject.narrow(ref, type);
        } catch(NamingException ne) {
            throw new EJBException(ne);
        }
    }

public String [] listAvailableCabins(int bedCount)
    throws IncompleteConversationalState { 
    if (cruise == null) 
        throw new IncompleteConversationalState();

    Connection con = null;
    PreparedStatement ps = null;;
    ResultSet result = null;
    try {
        Integer cruiseID = (Integer)cruise.getPrimaryKey();
	  Integer shipID = new Integer(cruise.getShipID());       
        con = getConnection();
        ps = con.prepareStatement(
            "select ID, NAME, DECK_LEVEL  from CABIN "+
            "where SHIP_ID = ? and BED_COUNT = ? and ID NOT IN "+
            "(SELECT CABIN_ID FROM RESERVATION "+
            " WHERE CRUISE_ID = ?)");

        ps.setInt(1,shipID.intValue());
        ps.setInt(2, bedCount);
        ps.setInt(3,cruiseID.intValue());
        result = ps.executeQuery();
        Vector vect = new Vector();
        while(result.next()) {
            StringBuffer buf = new StringBuffer();
            buf.append(result.getString(1));
            buf.append(',');
            buf.append(result.getString(2));
            buf.append(',');
            buf.append(result.getString(3));
            vect.addElement(buf.toString());
        }
        String [] returnArray = new String[vect.size()];
        vect.copyInto(returnArray);
        return returnArray;
    }
    catch (Exception e) {
        throw new EJBException(e);
    }
    finally {
        try {
        if (result != null) result.close();
        if (ps != null) ps.close();
        if (con!= null) con.close();
        }catch(SQLException se){se.printStackTrace();}
    }
}

private Connection getConnection() throws SQLException {
    try {
        DataSource ds = (DataSource)jndiContext.lookup(
            "java:comp/env/jdbc/titanDB");
        return ds.getConnection();
    } catch(NamingException ne) {throw new EJBException(ne);}
}
} 
