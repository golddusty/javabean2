package com.titan.travelagentclient;

import com.titan.travelagent.*;
import com.titan.customer.*;
import com.titan.processpayment.*;
import com.titan.reservation.*;
import com.titan.cruise.*;

import javax.naming.*;
import java.util.*;
import java.text.*;
import javax.rmi.PortableRemoteObject;

public class ReservationApplication {

	public static void main(String args[]) {
		try {
			Context jndiContext = getInitialContext();
			Object ref = jndiContext.lookup("CustomerHomeRemote");
			CustomerHomeRemote customerHome =(CustomerHomeRemote)
    				PortableRemoteObject.narrow(ref, CustomerHomeRemote.class);

			String ln = "Public";
			String fn = "John";
			String mn = "Q";
			int nextID = 2;
			CustomerRemote customer = customerHome.create(nextID, ln, fn, mn); 

			Object tref = jndiContext.lookup("TravelAgentHomeRemote");
			TravelAgentHomeRemote home = (TravelAgentHomeRemote)
    				PortableRemoteObject.narrow(tref, TravelAgentHomeRemote.class);
        
			TravelAgentRemote agent = home.create(customer);
			Integer cruise_id = new Integer(1); 

			Object cref = jndiContext.lookup("CruiseHomeRemote");
			CruiseHomeRemote chome = (CruiseHomeRemote)
    				PortableRemoteObject.narrow(cref, CruiseHomeRemote.class);

			chome.create(1, "Bahamas paradise", 1);	
 
			Integer cabin_id = new Integer(1);	// created earlier in ex 4.1
			agent.setCruiseID(cruise_id);
			agent.setCabinID(cabin_id);

			String cardNumber = "12345678901234";

			DateFormat dateFormatter = DateFormat.getDateInstance(DateFormat.SHORT);
			Date date = 
    				dateFormatter.parse("1/1/2002");
			String cardBrand = "Amex";
			CreditCardDO card = new CreditCardDO(cardNumber,date,cardBrand);
			double price = 1000.0;

			TicketDO ticket = agent.bookPassage(card,price);
			System.out.println(ticket);


			/*  At this point it would be a good idea to clean things out.
			 * in particular you need to delete the Customer, Cruise and 
			 * Reservation that have been created.
			 */

		} catch (Exception e) {
			System.out.println("Exception caught " + e);
			e.printStackTrace();
		}
	}

    public static Context getInitialContext() 
        throws javax.naming.NamingException {

		java.util.Properties properties = new java.util.Properties();
		properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
		properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, 
			"com.ibm.websphere.naming.WsnInitialContextFactory");
		InitialContext initialContext = new InitialContext(properties);
		return initialContext;
    }
}