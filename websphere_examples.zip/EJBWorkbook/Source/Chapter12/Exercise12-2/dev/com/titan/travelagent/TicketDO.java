package com.titan.travelagent;

import com.titan.cruise.CruiseRemote;
import com.titan.cabin.CabinRemote;
import com.titan.customer.CustomerRemote;
import java.rmi.RemoteException;

public class TicketDO implements java.io.Serializable {
    public Integer customerID;
    public Integer cruiseID;
    public Integer cabinID;
    public double price;
    public String description;
    
    public TicketDO(CustomerRemote customer, 
        CruiseRemote cruise, CabinRemote cabin, 
        double amount)
        throws javax.ejb.FinderException, RemoteException,  
            javax.naming.NamingException {
        
            description = customer.getFirstName()+
                " " + customer.getLastName() + 
                " has been booked for the "
                + cruise.getName() + 
                " cruise on ship " + cruise.getShipID() + ".\n" +  
                " Your accommodations include " + 
                  cabin.getName() + 
                " a " + cabin.getBedCount() + 
                " bed cabin on deck level " + cabin.getDeckLevel() + 
                ".\n Total charge = " + amount;

            customerID = (Integer)customer.getPrimaryKey();
            cruiseID = (Integer)cruise.getPrimaryKey();
            cabinID = (Integer)cabin.getPrimaryKey();
            price = amount;

        }
    public String toString() {
        return description;
    }
}
