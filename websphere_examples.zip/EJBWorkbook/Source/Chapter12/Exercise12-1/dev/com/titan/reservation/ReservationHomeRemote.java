package com.titan.reservation;

import java.util.Enumeration;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import com.titan.cruise.CruiseRemote;
import com.titan.customer.CustomerRemote;
import com.titan.cabin.CabinRemote;

public interface ReservationHomeRemote extends javax.ejb.EJBHome {

    public ReservationRemote create(CustomerRemote customer, CruiseRemote cruise,CabinRemote cabin, double price, java.sql.Date travelDate)
    throws RemoteException, CreateException;

    public ReservationRemote findByPrimaryKey(ReservationPK pk)
    throws RemoteException, FinderException;

}