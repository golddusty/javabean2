package com.titan.reservation;

import com.titan.cabin.*;
import com.titan.cruise.*;
import com.titan.customer.*;

import javax.ejb.*;
import java.rmi.RemoteException;


public class ReservationBean implements javax.ejb.EntityBean {
    
    public int customerID;
    public int cruiseID;
    public int cabinID;
    public double price;
    public java.sql.Date date;
    
   
    public javax.ejb.EntityContext ejbContext;

    public ReservationPK ejbCreate(CustomerRemote customer, CruiseRemote cruise, CabinRemote cabin, double price, java.sql.Date travelDate) {
        try {
            this.customerID = ((Integer)customer.getPrimaryKey()).intValue();
            this.cruiseID = ((Integer)cruise.getPrimaryKey()).intValue();
            this.cabinID = ((Integer)cabin.getPrimaryKey()).intValue();
            this.price = price;
		this.date = travelDate;
        }
        catch (RemoteException re) {
            throw new EJBException(re);
        }
        return null;
    }

    public void ejbPostCreate(CustomerRemote customer, CruiseRemote cruise, CabinRemote cabin, double price, java.sql.Date travelDate){
        // do nothing;
    }
    public double getPrice( ){
        return price;
    }
    public int getCabinID( ){
        return cabinID;
    }
    public int getCustomerID( ){
        return customerID;
    }
    public int getCruiseID( ){
        return cruiseID;
    }

    public java.sql.Date getDate( ){
        return date;
    }

    public void setEntityContext(javax.ejb.EntityContext ctx){
	ejbContext = ctx;
    }
    public void unsetEntityContext(){
	ejbContext = null;
    }
    public void ejbActivate(){
        // not implemented
    }
    public void ejbPassivate(){
        // not implemented
    }
    public void ejbLoad(){
        // not implemented
    }
    public void ejbStore(){
        // not implemented
    }
    public void ejbRemove(){
        // not implemented
    }
}
