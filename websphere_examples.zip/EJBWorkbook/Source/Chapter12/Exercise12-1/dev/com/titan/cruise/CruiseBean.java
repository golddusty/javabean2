package com.titan.cruise;

import javax.ejb.EntityContext;
import javax.ejb.FinderException;

public class CruiseBean implements javax.ejb.EntityBean {

    public Integer id;
    public String name;
    public int shipID;

    public javax.ejb.EntityContext ejbContext;

    public Integer ejbCreate(int id, String name, int shipID){
        this.id = new Integer(id);
        this.name = name;
        this.shipID = shipID;
        return null;
    }
    public void ejbPostCreate(int id, String name, int shipID){
        // do nothing. Required
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public int getShipID( ){
        return shipID;
    }
    public void setShipID(int shipID){
        this.shipID = shipID;
    }
	public void setEntityContext(EntityContext ctx){
	     ejbContext = ctx;
    }
    public void unsetEntityContext(){
         ejbContext = null;
    }
    public void ejbActivate(){
        // not implemented
    }
    public void ejbPassivate(){
        // not implemented
    }
    public void ejbLoad(){
        // not implemented
    }
    public void ejbStore(){
        // not implemented
    }
    public void ejbRemove(){
        // not implemented
    }
}
