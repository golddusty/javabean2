package com.titan.cruise;

import java.rmi.RemoteException;

public interface CruiseRemote extends javax.ejb.EJBObject {

    public String getName( )throws RemoteException;
    public void setName(String name)throws RemoteException;
    public int getShipID()throws RemoteException;
    public void setShipID(int shipID)throws RemoteException;
    
}
