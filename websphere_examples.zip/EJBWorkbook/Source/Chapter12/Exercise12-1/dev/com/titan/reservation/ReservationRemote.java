package com.titan.reservation;

import com.titan.cabin.CabinRemote;
import com.titan.cruise.CruiseRemote;
import com.titan.customer.CustomerRemote;
import java.rmi.RemoteException;

public interface ReservationRemote extends javax.ejb.EJBObject {
    public int getCabinID( ) throws RemoteException;
    public int getCruiseID( ) throws RemoteException;
    public int getCustomerID( ) throws RemoteException;
    public double getPrice( ) throws RemoteException;
    public java.sql.Date getDate() throws RemoteException;
}