package com.titan.customer;
import java.rmi.RemoteException;

public interface CustomerHomeRemote extends javax.ejb.EJBHome {

    public CustomerRemote create(int id, String lastName, String firstName, String middleName)
    throws RemoteException, javax.ejb.CreateException;

    public CustomerRemote findByPrimaryKey(Integer pk)
    throws RemoteException, javax.ejb.FinderException;

}