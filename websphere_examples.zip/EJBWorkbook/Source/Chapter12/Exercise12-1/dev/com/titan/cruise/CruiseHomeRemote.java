package com.titan.cruise;
import java.rmi.RemoteException;

import java.util.Enumeration;

public interface CruiseHomeRemote extends javax.ejb.EJBHome {

    public CruiseRemote create(int id, String name,int shipID)
    throws RemoteException, javax.ejb.CreateException;

    public CruiseRemote findByPrimaryKey(Integer pk)
    throws RemoteException, javax.ejb.FinderException;
}
