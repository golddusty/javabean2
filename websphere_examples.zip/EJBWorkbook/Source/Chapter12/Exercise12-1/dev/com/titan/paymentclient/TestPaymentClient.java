package com.titan.paymentclient;

import com.titan.customer.*;

import com.titan.processpayment.ProcessPaymentHomeRemote;
import com.titan.processpayment.ProcessPaymentRemote;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import java.rmi.RemoteException;
import java.util.Properties;

public class TestPaymentClient {
    public static void main(String [] args) {
		TestPaymentClient client = new TestPaymentClient();
		client.createSampleCustomer();
		client.payByCash();
    }

    public static Context getInitialContext() 
        throws javax.naming.NamingException {

		java.util.Properties properties = new java.util.Properties();
		properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
		properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, 
			"com.ibm.websphere.naming.WsnInitialContextFactory");
		InitialContext initialContext = new InitialContext(properties);
		return initialContext;
    }

	public ProcessPaymentHomeRemote getProcessPaymentHome() {
		ProcessPaymentHomeRemote home = null;
		try {
            	Context jndiContext = getInitialContext();
            	Object ref = jndiContext.lookup("ProcessPaymentHomeRemote");
            	home = (ProcessPaymentHomeRemote)
                      javax.rmi.PortableRemoteObject.narrow(ref,ProcessPaymentHomeRemote.class);
		} catch (NamingException ne) {
			ne.printStackTrace();
		}			
		return home;
	}

	public CustomerHomeRemote getCustomerHome() {
		CustomerHomeRemote home = null;
		try {
            	Context jndiContext = getInitialContext();
            	Object ref = jndiContext.lookup("CustomerHomeRemote");
            	home = (CustomerHomeRemote)
                      javax.rmi.PortableRemoteObject.narrow(ref,CustomerHomeRemote.class);
		} catch (NamingException ne) {
			ne.printStackTrace();
		}			
		return home;
	}

	public void createSampleCustomer() {
	  try {
            CustomerRemote customer = getCustomerHome().create(1,"Kyle","G","Brown");
        } catch (java.rmi.RemoteException re){re.printStackTrace();}
          catch (javax.ejb.CreateException ce){ce.printStackTrace();}
	}

	public void payByCash() {    
		try {  
            	Integer pk = new Integer(1);
            	CustomerRemote customer = getCustomerHome().findByPrimaryKey(pk);
            	ProcessPaymentRemote paymentBean = getProcessPaymentHome().create();
			paymentBean.byCash(customer, 1000.0);
		}  catch (Exception e){
			e.printStackTrace();
		}
	}
}
