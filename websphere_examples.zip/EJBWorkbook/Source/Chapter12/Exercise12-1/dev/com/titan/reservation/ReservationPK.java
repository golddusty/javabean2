package com.titan.reservation;

public class ReservationPK implements java.io.Serializable {

    public int cruiseID;
    public int cabinID;

    public ReservationPK(){}
    public ReservationPK(int crsID, int cbnID){
        cruiseID = crsID;
        cabinID = cbnID;
    }
    public int hashCode( ){
       return toString().hashCode();
    }
    
    public boolean equals(Object obj){
         if(obj instanceof ReservationPK)
             return (((ReservationPK)obj).cruiseID == cruiseID && ((ReservationPK)obj).cabinID == cabinID);
         
         return false;
    }
    
    public String toString( ){
        return cruiseID+""+cabinID;
    }
    
}
