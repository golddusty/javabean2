package com.titan.customer;

import javax.ejb.EntityContext;

public class CustomerBean implements javax.ejb.EntityBean {

    public Integer id;
    public String lastName;
    public String firstName;
    public String middleName;

    private EntityContext context = null;

    public Integer ejbCreate(int id, String lastName, String firstName, String middleName){
        this.id = new Integer(id);
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleName = middleName;
        return null;
    }
    public void ejbPostCreate(int id, String lastName, String firstName, String middleName){
        // do nothing. Required
    }
    public String getLastName(){
        return lastName;
    }
    public void setLastName(String name){
        lastName = name;
    }
    public String getFirstName(){
        return firstName;
    }
    public void setFirstName(String name){
        firstName = name;
    }
    public String getMiddleName(){
        return middleName;
    }
    public void setMiddleName(String name){
        middleName = name;
    }

    public void setEntityContext(EntityContext ctx){
	 context = ctx;
    }
    public void unsetEntityContext(){
       context = null;
    }
    public void ejbActivate(){
        // not implemented
    }
    public void ejbPassivate(){
        // not implemented
    }
    public void ejbLoad(){
        // not implemented
    }
    public void ejbStore(){
        // not implemented
    }
    public void ejbRemove(){
        // not implemented
    }
}
