package com.titan.shipclient;

import javax.naming.*;
import com.titan.ship.*;
import java.util.*;

public class ShipTestClient {

	public static void main(String[] args) {
		try {
			Context jndiContext = getInitialContext();
			Object ref = jndiContext.lookup("BmpShipHomeRemote");
			ShipHomeRemote home =
				(ShipHomeRemote) javax.rmi.PortableRemoteObject.narrow(
					ref,
					ShipHomeRemote.class);
			ShipRemote ship1 = home.create(new Integer(1), "Andrea Doria", 2000, 2500);

			System.out.println("Adding ship 1");
			System.out.println(ship1.getName());
			System.out.println(ship1.getCapacity());
			System.out.println(ship1.getTonnage());

			ShipRemote ship2 = home.create(new Integer(2), "Marie Celeste", 5000, 2500);

			System.out.println("Adding ship 2");
			System.out.println(ship2.getName());
			System.out.println(ship2.getCapacity());
			System.out.println(ship2.getTonnage());
			
			System.out.println("Ships of capacity = 5000 are:");
			Collection coll = home.findByCapacity(5000);
			Enumeration enum = Collections.enumeration(coll);
			while (enum.hasMoreElements()) {
				Object shipRef = enum.nextElement();
				ShipRemote ship = (ShipRemote) javax.rmi.PortableRemoteObject.narrow(shipRef, ShipRemote.class);
				System.out.println(ship.getName());
			}

		} catch (java.rmi.RemoteException re) {
			re.printStackTrace();
		} catch (javax.naming.NamingException ne) {
			ne.printStackTrace();
		} catch (javax.ejb.CreateException ce) {
			ce.printStackTrace();
		} catch (javax.ejb.FinderException fe) {
			fe.printStackTrace();
		}

	}

	public static Context getInitialContext() throws javax.naming.NamingException {

		java.util.Properties properties = new java.util.Properties();
		properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
		properties.put(
			javax.naming.Context.INITIAL_CONTEXT_FACTORY,
			"com.ibm.websphere.naming.WsnInitialContextFactory");
		InitialContext initialContext = new InitialContext(properties);
		return initialContext;
	}
}