package com.titan.travelagent;

import com.titan.cabin.CabinRemote;
import com.titan.cabin.CabinHomeRemote;
import java.rmi.RemoteException;
import javax.naming.InitialContext;
import javax.naming.Context;
import java.util.Properties;
import java.util.Vector;

public class TravelAgentBean implements javax.ejb.SessionBean {

   public void ejbCreate() {
   // Do nothing.
   }
   public String [] listCabins(int shipID, int bedCount) {

	CabinRemote cabin = null;

        try {
            javax.naming.Context jndiContext = new InitialContext();
            Object obj = 
                   jndiContext.lookup("java:comp/env/ejb/CabinHomeRemote");

            CabinHomeRemote home = (CabinHomeRemote)
            javax.rmi.PortableRemoteObject.narrow(obj,CabinHomeRemote.class);
    
            Vector vect = new Vector();
            for (int i = 1; ; i++) {
              Integer pk = new Integer(i);
              try {
                  cabin = home.findByPrimaryKey(pk);
                } catch(javax.ejb.FinderException fe) {
                    break;
                }
                // Check to see if the bed count and ship ID match.
                if (cabin.getShipId() == shipID && 
                    cabin.getBedCount() == bedCount) {
                  String details = 
                    i+","+cabin.getName()+","+cabin.getDeckLevel();
                  vect.addElement(details);
                }
            }
        
            String [] list = new String[vect.size()];
            vect.copyInto(list);
            return list;
       
       } catch(Exception e) {throw new javax.ejb.EJBException(e);}    
   }

    public Context getInitialContext() 
        throws javax.naming.NamingException {

		java.util.Properties properties = new java.util.Properties();
		properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
		properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, 
			"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		InitialContext initialContext = new InitialContext(properties);
		return initialContext;
    }

   public void ejbRemove(){}
   public void ejbActivate(){}
   public void ejbPassivate(){}
   public void setSessionContext(javax.ejb.SessionContext cntx){}
}