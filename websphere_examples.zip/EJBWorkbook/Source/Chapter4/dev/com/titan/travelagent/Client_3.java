package com.titan.travelagent;

import com.titan.cabin.CabinHomeRemote;
import com.titan.cabin.CabinRemote;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import java.util.Properties;

public class Client_3 {
    public static int SHIP_ID = 1;
    public static int BED_COUNT = 3;

    public static void main(String [] args) {
        try {
           Context jndiContext = getInitialContext();
           
           Object ref = (TravelAgentHomeRemote)
               jndiContext.lookup("TravelAgentHomeRemote");
           TravelAgentHomeRemote home = (TravelAgentHomeRemote)
               javax.rmi.PortableRemoteObject.narrow(ref,TravelAgentHomeRemote.class);
        
           TravelAgentRemote travelAgent = home.create();
        
           // Get a list of all cabins on ship 1 with a bed count of 3.
           String list [] = travelAgent.listCabins(SHIP_ID,BED_COUNT);
        
           for(int i = 0; i < list.length; i++){
              System.out.println(list[i]);
           }
        
        } catch(java.rmi.RemoteException re){re.printStackTrace();}
          catch(Throwable t){t.printStackTrace();}
  }

    public static Context getInitialContext() 
        throws javax.naming.NamingException {
		java.util.Properties properties = new java.util.Properties();
		properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
		properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, 
			"com.ibm.websphere.naming.WsnInitialContextFactory");
		InitialContext initialContext = new InitialContext(properties);
		return initialContext;
    }
}
