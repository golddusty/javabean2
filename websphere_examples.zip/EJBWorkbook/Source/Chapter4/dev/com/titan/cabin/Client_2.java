package com.titan.cabin;

import com.titan.cabin.CabinHomeRemote;
import com.titan.cabin.CabinRemote;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import java.util.Properties;

public class Client_2 {

    public static void main(String [] args) {
        try {
		System.out.println("Trying to obtain initial context.");
            Context jndiContext = getInitialContext();
            System.out.println("InitialContext obtained.");
            Object ref = 
                jndiContext.lookup("CabinHomeRemote");
		System.out.println("CabinHome found");
            CabinHomeRemote home = (CabinHomeRemote)
                      javax.rmi.PortableRemoteObject.narrow(ref,CabinHomeRemote.class);
		System.out.println("Narrow finished -- proceeding to make cabins");
            // Add 9 cabins to deck 1 of ship 1.
            makeCabins(home, 2, 10, 1, 1);
            // Add 10 cabins to deck 2 of ship 1.
            makeCabins(home, 11, 20, 2, 1);
            // Add 10 cabins to deck 3 of ship 1.
            makeCabins(home, 21, 30, 3, 1);
            
            // Add 10 cabins to deck 1 of ship 2.
            makeCabins(home, 31, 40, 1, 2);
            // Add 10 cabins to deck 2 of ship 2.
            makeCabins(home, 41, 50, 2, 2);
            // Add 10 cabins to deck 3 of ship 2.
            makeCabins(home, 51, 60, 3, 2);
            
            // Add 10 cabins to deck 1 of ship 3.
            makeCabins(home, 61, 70, 1, 3);
            // Add 10 cabins to deck 2 of ship 3.
            makeCabins(home, 71, 80, 2, 3);
            // Add 10 cabins to deck 3 of ship 3.
            makeCabins(home, 81, 90, 3, 3);
            // Add 10 cabins to deck 4 of ship 3.
            makeCabins(home, 91, 100, 4, 3);

            for (int i = 1; i <= 100; i++){
                Integer pk = new Integer(i);
                CabinRemote cabin = home.findByPrimaryKey(pk);
                System.out.println("PK = "+i+", Ship = "+cabin.getShipId()
                  + ", Deck = "+cabin.getDeckLevel()
                  + ", BedCount = "+cabin.getBedCount()
                  + ", Name = "+cabin.getName());
            }

        } catch (java.rmi.RemoteException re) {re.printStackTrace();}
          catch (javax.naming.NamingException ne) {ne.printStackTrace();}
          catch (javax.ejb.CreateException ce) {ce.printStackTrace();}
          catch (javax.ejb.FinderException fe) {fe.printStackTrace();}
  }

 public static Context getInitialContext() 
        throws javax.naming.NamingException {
		java.util.Properties properties = new java.util.Properties();
		properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
		properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, 
			"com.ibm.websphere.naming.WsnInitialContextFactory");
		InitialContext initialContext = new InitialContext(properties);
		return initialContext;
    }
  public static void makeCabins(CabinHomeRemote home, 
                                int fromId, int toId, 
                                int deckLevel, int shipNumber)
    throws RemoteException, CreateException {

    int bc = 3;
    for (int i = fromId; i <= toId; i++) {        
        CabinRemote cabin = home.create(new Integer(i));
        int suiteNumber = deckLevel*100+(i-fromId);
        cabin.setName("Suite "+suiteNumber);
        cabin.setDeckLevel(deckLevel);
        bc = (bc==3)?2:3;
        cabin.setBedCount(bc);
        cabin.setShipId(shipNumber);
    }
  }
}