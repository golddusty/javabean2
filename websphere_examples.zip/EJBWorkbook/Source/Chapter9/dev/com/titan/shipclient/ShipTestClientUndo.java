package com.titan.shipclient;

import javax.naming.*;
import com.titan.ship.*;

public class ShipTestClientUndo {

	public static void main(String[] args) {
		try {
			Context jndiContext = getInitialContext();
			Object ref = jndiContext.lookup("ShipHomeRemote");
			ShipHomeRemote home =
				(ShipHomeRemote) javax.rmi.PortableRemoteObject.narrow(
					ref,
					ShipHomeRemote.class);
			
			ShipRemote ship1 = home.findByPrimaryKey(new Integer(1));
			ship1.remove();
			
			ShipRemote ship2 = home.findByPrimaryKey(new Integer(2));
			ship2.remove();

			System.out.println("Undo Completed Successfully");
			
		} catch (java.rmi.RemoteException re) {
			re.printStackTrace();
		} catch (javax.naming.NamingException ne) {
			ne.printStackTrace();
		} catch (javax.ejb.RemoveException re) {
			re.printStackTrace();
		}catch (javax.ejb.FinderException fe) {
			fe.printStackTrace();
		}

	}

	public static Context getInitialContext() throws javax.naming.NamingException {

		java.util.Properties properties = new java.util.Properties();
		properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
		properties.put(
			javax.naming.Context.INITIAL_CONTEXT_FACTORY,
			"com.ibm.websphere.naming.WsnInitialContextFactory");
		InitialContext initialContext = new InitialContext(properties);
		return initialContext;
	}
}