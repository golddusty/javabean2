package com.titan.customer;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.rmi.RemoteException;

public interface CustomerHomeRemote extends javax.ejb.EJBHome {
    
    public CustomerLocal create(Integer id)
        throws CreateException,RemoteException;
    
    public CustomerLocal findByPrimaryKey(Integer id)
        throws FinderException, RemoteException;
    
}

